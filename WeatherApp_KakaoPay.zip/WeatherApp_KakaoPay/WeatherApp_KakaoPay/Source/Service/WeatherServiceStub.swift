//
//  ForecastServiceStub.swift
//  WeatherApp_KakaoPay
//
//  Created by Sicc on 05/08/2019.
//  Copyright © 2019 chang sic jung. All rights reserved.
//

import Foundation

//class WeatherServiceStub: WeatherServiceType {
//  
//  func fetchWeather(latitude: Double, longitude: Double, completionHandler: @escaping (Result<Weather, ServiceError>) -> Void) {
//    let data = SampleData.forecast
//    let weather = try! JSONDecoder().decode(Weather.self, from: data)
//    completionHandler(.success(weather))
//  }
//  
//  
//}
