//
//  MyWeatherTableView.swift
//  WeatherApp_KakaoPay
//
//  Created by Sicc on 02/08/2019.
//  Copyright © 2019 chang sic jung. All rights reserved.
//

import UIKit

class MyWeatherListViewController: UIViewController {
  
  // MARK: - Data
  private var weather: [Weather]? {
    return DataManager.shared.getWeather()
  }
  
  override var preferredStatusBarStyle: UIStatusBarStyle {
    return .lightContent
  }
  
  private lazy var myWeatherTableView: UITableView = {

    let tv = UITableView(frame: .zero)
    tv.dataSource = self
    tv.delegate = self
    tv.register(cell: MyWeatherTableCell.self)
    tv.register(MyWeatherListFooterView.self, forHeaderFooterViewReuseIdentifier:  MyWeatherListFooterView.identifier)

    tv.rowHeight = ScreenBounds.height * 0.1
    tv.sectionFooterHeight = ScreenBounds.height * 0.13
    tv.backgroundColor = .clear
    view.addSubview(tv)
    return tv
  }()
  
  private let backgroundImageView: UIImageView = {
    let iv = UIImageView(frame: ScreenBounds.bounds)
    iv.image = UIImage(named: "night")
    iv.contentMode = .scaleToFill
    return iv
  }()
  
  // MARK: - ViewController LifeCyle
  override func viewDidLoad() {
    super.viewDidLoad()
    view.addSubview(backgroundImageView) // 이미지 뷰 가장 아래쪽에 위치하게
    configureReloadObserver()
    makeConstraints()
  }
  
  deinit {
    DataManager.shared.noti.removeObserver(self, name: NotificationID.DataDidChanged, object: nil)
  }
  
  // MARK: - Reload Notifications
  private func configureReloadObserver() {
    DataManager.shared.noti.addObserver(self, selector: #selector(reloadObserver(_:)), name: NotificationID.DataDidChanged, object: nil)
  }
  
  @objc func reloadObserver(_ sender: Any) {
    logger("Reload")
    DispatchQueue.main.async {
      self.myWeatherTableView.reloadData()
    }
  }
  
  // MARK: - Layout Methods
  private func makeConstraints() {
    myWeatherTableView.layout.top().leading().trailing().bottom()
  }
}

// MARK: - TableView DataSource
extension MyWeatherListViewController: UITableViewDataSource {
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return weather?.count ?? 0
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeue(MyWeatherTableCell.self)
    guard let weather = weather else { logger(ErrorLog.unwrap); return UITableViewCell() }
    if indexPath.row == 0 {
      cell.configureCell(weather[indexPath.row].locationInfo,
                         "",
                         weather[indexPath.row].currently.temperature.convertToCelsiusIntoString())
    } else {
      cell.configureCell(weather[indexPath.row].locationInfo,
                         weather[indexPath.row].currently.time.getHourToString(true),
                         weather[indexPath.row].currently.temperature.convertToCelsiusIntoString())
    }
    return cell
  }
  
}

// MARK: - TableView Delegate
extension MyWeatherListViewController: UITableViewDelegate {
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    if let weatherVC = self.presentingViewController as? WeatherViewController {
      weatherVC.pageControl.currentPage = indexPath.row
      weatherVC.weatherCollectionView.selectItem(at: indexPath, animated: true, scrollPosition: .centeredHorizontally)
    }
    self.dismiss(animated: true, completion: nil)
  }
  
  func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
    let footer = tableView.dequeueReusableHeaderFooterView(withIdentifier: MyWeatherListFooterView.identifier) as! MyWeatherListFooterView
    footer.plusButtonDidTap = {
      self.present(SearchLocationViewController(), animated: true, completion: nil)
    }
    return footer
  }
  
  func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
    if editingStyle == .delete {
      DataManager.shared.removeWeahter(at: indexPath.row)
      self.myWeatherTableView.reloadData()
    }
  }
  
  func tableView(_ tableView: UITableView, willDisplayFooterView view: UIView, forSection section: Int) {
    let footer = view as! MyWeatherListFooterView
    footer.backgroundView?.backgroundColor = .clear
  }
}
